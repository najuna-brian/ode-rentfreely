import{j as o}from"./index-VEd8d2BG.js";import{c as t}from"./Stack-B8vhOAoX.js";const r=t(o.jsx("path",{d:"M12 2 4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"}),"Navigation");export{r as N};
