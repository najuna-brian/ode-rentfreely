import{g as v,c as k,r as S,d as C,j as h,f as N,h as w,s as B,m as L,L as m,M as p,l as A}from"./index-B_99gnbV.js";import{c as M}from"./Stack-S712LS5r.js";function R(e){return String(e).match(/[\d.\-+]*\s*(.*)/)[1]||""}function U(e){return parseFloat(e)}function x(e){return v("MuiSkeleton",e)}k("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);const P=e=>{const{classes:t,variant:n,animation:o,hasChildren:i,width:r,height:a}=e;return w({root:["root",n,o,i&&"withChildren",i&&!r&&"fitContent",i&&!a&&"heightAuto"]},x,t)},l=m`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`,u=m`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`,E=typeof l!="string"?p`
        animation: ${l} 2s ease-in-out 0.5s infinite;
      `:null,F=typeof u!="string"?p`
        &::after {
          animation: ${u} 2s linear 0.5s infinite;
        }
      `:null,T=B("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,t)=>{const{ownerState:n}=e;return[t.root,t[n.variant],n.animation!==!1&&t[n.animation],n.hasChildren&&t.withChildren,n.hasChildren&&!n.width&&t.fitContent,n.hasChildren&&!n.height&&t.heightAuto]}})(L(({theme:e})=>{const t=R(e.shape.borderRadius)||"px",n=U(e.shape.borderRadius);return{display:"block",backgroundColor:e.vars?e.vars.palette.Skeleton.bg:A(e.palette.text.primary,e.palette.mode==="light"?.11:.13),height:"1.2em",variants:[{props:{variant:"text"},style:{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${n}${t}/${Math.round(n/.6*10)/10}${t}`,"&:empty:before":{content:'"\\00a0"'}}},{props:{variant:"circular"},style:{borderRadius:"50%"}},{props:{variant:"rounded"},style:{borderRadius:(e.vars||e).shape.borderRadius}},{props:({ownerState:o})=>o.hasChildren,style:{"& > *":{visibility:"hidden"}}},{props:({ownerState:o})=>o.hasChildren&&!o.width,style:{maxWidth:"fit-content"}},{props:({ownerState:o})=>o.hasChildren&&!o.height,style:{height:"auto"}},{props:{animation:"pulse"},style:E||{animation:`${l} 2s ease-in-out 0.5s infinite`}},{props:{animation:"wave"},style:{position:"relative",overflow:"hidden",WebkitMaskImage:"-webkit-radial-gradient(white, black)","&::after":{background:`linear-gradient(
                90deg,
                transparent,
                ${(e.vars||e).palette.action.hover},
                transparent
              )`,content:'""',position:"absolute",transform:"translateX(-100%)",bottom:0,left:0,right:0,top:0}}},{props:{animation:"wave"},style:F||{"&::after":{animation:`${u} 2s linear 0.5s infinite`}}}]}})),q=S.forwardRef(function(t,n){const o=C({props:t,name:"MuiSkeleton"}),{animation:i="pulse",className:r,component:a="span",height:c,style:g,variant:y="text",width:b,...d}=o,f={...o,animation:i,component:a,variant:y,hasChildren:!!d.children},_=P(f);return h.jsx(T,{as:a,ref:n,className:N(_.root,r),ownerState:f,...d,style:{width:b,height:c,...g}})}),I=M(h.jsx("path",{d:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"}),"ArrowBack");function K(e){return e==null||isNaN(e)?"UGX —":`UGX ${Number(e).toLocaleString("en-UG")}`}function Y(e){if(!e)return null;if(typeof e=="object"&&e.latitude!=null&&e.longitude!=null)return{lat:Number(e.latitude),lng:Number(e.longitude)};if(typeof e=="string"){try{const n=JSON.parse(e);if((n==null?void 0:n.latitude)!=null&&(n==null?void 0:n.longitude)!=null)return{lat:Number(n.latitude),lng:Number(n.longitude)}}catch{}const t=e.split(",").map(n=>parseFloat(n.trim()));if(t.length>=2&&!isNaN(t[0])&&!isNaN(t[1]))return{lat:t[0],lng:t[1]}}return null}function J(e){if(!e||typeof e!="string")return null;const t=e.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);if(t){const r=parseFloat(t[1]),a=parseFloat(t[2]);if(s(r,a))return{lat:r,lng:a}}const n=e.match(/[?&]q=(-?\d+\.?\d*)[,+](-?\d+\.?\d*)/);if(n){const r=parseFloat(n[1]),a=parseFloat(n[2]);if(s(r,a))return{lat:r,lng:a}}const o=e.match(/geo:(-?\d+\.?\d*),(-?\d+\.?\d*)/);if(o){const r=parseFloat(o[1]),a=parseFloat(o[2]);if(s(r,a))return{lat:r,lng:a}}const i=e.match(/(-?\d+\.?\d+)[,\s]+(-?\d+\.?\d+)/);if(i){const r=parseFloat(i[1]),a=parseFloat(i[2]);if(s(r,a))return{lat:r,lng:a}}return null}function s(e,t){return!isNaN(e)&&!isNaN(t)&&e>=-90&&e<=90&&t>=-180&&t<=180}const $={single_room:"Single Room",double_room:"Double Room",bedsitter:"Bedsitter / Studio","1_bedroom":"1 Bedroom","2_bedroom":"2 Bedroom","3_bedroom":"3 Bedroom","4_plus_bedroom":"4+ Bedroom",standalone:"Standalone House",bungalow:"Bungalow",mansion:"Mansion",shop:"Shop / Commercial",office:"Office Space",warehouse:"Warehouse",other:"Other"};function V(e){return $[e]||e||"—"}const j={monthly:"Monthly",quarterly:"Quarterly",biannually:"Every 6 months",annually:"Annually"};function z(e){return j[e]||e||"—"}const H={available:"Available",available_soon:"Available Soon",reserved:"Reserved",occupied:"Occupied"};function Q(e){return H[e]||e||"—"}function Z(e){return{available:"success",available_soon:"info",reserved:"warning",occupied:"error"}[e]||"default"}function O(e){if(!e)return null;if(typeof e=="string"){if(e.startsWith("{"))try{const t=JSON.parse(e);return t.url||t.uri||null}catch{}return e}return typeof e=="object"&&(e.url||e.uri)||null}function D(e){return e?["photo_front","photo_interior","photo_bedroom","photo_bathroom","photo_extra"].map(n=>O(e[n])).filter(Boolean):[]}function ee(e){return e&&[e.village,e.parish,e.district].filter(Boolean).join(", ")||"—"}function te(e){return e?[e.village,e.parish,e.sub_county,e.county,e.district,e.region?`${e.region} Region`:null,"Uganda"].filter(Boolean).join(", "):"—"}const W=[{key:"has_running_water",label:"Water",iconName:"WaterDrop"},{key:"has_electricity",label:"Electricity",iconName:"Bolt"},{key:"has_parking",label:"Parking",iconName:"LocalParking"},{key:"has_security",label:"Security",iconName:"Lock"},{key:"has_compound",label:"Compound",iconName:"Park"},{key:"has_kitchen",label:"Kitchen",iconName:"Countertops"},{key:"has_living_room",label:"Living Room",iconName:"Weekend"},{key:"has_balcony",label:"Balcony",iconName:"Balcony"},{key:"is_self_contained",label:"Self-Contained",iconName:"Shower"},{key:"is_furnished",label:"Furnished",iconName:"Chair"}];function ne(e){return e?W.filter(t=>e[t.key]===!0):[]}function oe(e,t={}){return e.filter(n=>{const o=n.data;if(!o||o.availability_status!=="available"&&o.availability_status!=="available_soon"||t.region&&o.region!==t.region||t.district&&o.district!==t.district||t.houseType&&o.house_type!==t.houseType||t.minPrice&&o.monthly_rent_ugx<t.minPrice||t.maxPrice&&o.monthly_rent_ugx>t.maxPrice||t.minBedrooms&&o.num_bedrooms<t.minBedrooms||t.selfContained&&!o.is_self_contained||t.furnished&&!o.is_furnished)return!1;if(t.search){const i=t.search.toLowerCase();if(![o.title,o.description,o.village,o.parish,o.sub_county,o.district].filter(Boolean).join(" ").toLowerCase().includes(i))return!1}return!0})}export{I as A,q as S,K as a,D as b,ne as c,z as d,Z as e,oe as f,V as g,Q as h,te as i,O as j,J as k,Y as p,ee as s};
